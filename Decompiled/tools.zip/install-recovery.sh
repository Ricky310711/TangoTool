#!/system/bin/sh

# DooMLoRD: enabling init.d support
/system/bin/sysinit
